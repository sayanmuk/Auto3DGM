add <-
function(File,txt){
  File=paste(File,txt,"\n", sep="")
  return(File)
}
