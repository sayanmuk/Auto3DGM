nre <-
function( num ){ 
str=formatC(num,digits = 7, format="e");
return(str)
}
