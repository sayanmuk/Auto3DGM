f_scale <-
function(X){
  return(norm(f_center(X), "F") )
}
