isempty <-
function(X){
  if (length(X)==0) {
    return(T)
  }else return(F) 
}
