nr <-
function(num){
  str = format(num)
  return(str)
}
